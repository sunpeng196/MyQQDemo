// ChatDlg.cpp : ʵ���ļ�
//

#include "stdafx.h"
#include "QQ.h"
#include "ChatDlg.h"
#include "GlobalUnits.h"

// CChatDlg �Ի���

IMPLEMENT_DYNAMIC(CChatDlg, CSkinManager)

CChatDlg::CChatDlg(CWnd* pParent /*=NULL*/)
	: CSkinManager(IDD_CHAT, pParent)
{
	m_pBuddyItem = NULL;
}

CChatDlg::~CChatDlg()
{
}

void CChatDlg::DoDataExchange(CDataExchange* pDX)
{
	CSkinManager::DoDataExchange(pDX);
}


BEGIN_MESSAGE_MAP(CChatDlg, CSkinManager)
END_MESSAGE_MAP()

void CChatDlg::OnCancel()
{
	vector<CChatDlg*>::iterator iter = GlobalUnits->m_ChatArray.begin();

	for (;iter != GlobalUnits->m_ChatArray.end(); ++iter )
	{
		CChatDlg* pChatDlg = *iter;

		if( StrCmp(pChatDlg->m_pBuddyItem->m_strQQNum,m_pBuddyItem->m_strQQNum) == 0 )
		{
			pChatDlg->DestroyWindow();

			SafeDelete(pChatDlg);

			GlobalUnits->m_ChatArray.erase(iter);

			return;
		}
	}

	__super::OnCancel();
}


// CChatDlg ��Ϣ��������
