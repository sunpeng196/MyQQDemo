#pragma once


// CSkinManager �Ի���

//////////////////////////////////////////////////////////////////////////

class CSkinManager : public CSkinDialog
{
	DECLARE_DYNAMIC(CSkinManager)
public:
	CImageEx						*m_pImageBack;
	CImageEx						* m_pImageLogo;

	CSkinButton						m_btClose;
	CSkinButton						m_btMin;

public:
	CSkinManager(UINT nIDTemplate,CWnd* pParent = NULL);   // ��׼���캯��
	virtual ~CSkinManager();

protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV ֧��
	//���ڻ���
	virtual void DrawClientArea(CDC*pDC,int nWidth,int nHeight);

	void UpdateSkin();

	virtual BOOL OnInitDialog();

	afx_msg void OnBnClickWindowMin();

	afx_msg void OnLButtonDown(UINT nFlags, CPoint point);

	afx_msg void OnDestroy();

	DECLARE_MESSAGE_MAP()
};
