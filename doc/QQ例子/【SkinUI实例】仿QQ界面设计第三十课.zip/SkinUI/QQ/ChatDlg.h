#pragma once

#include "SkinManager.h"
#include "BuddyListBox.h"

// CChatDlg �Ի���

class CChatDlg : public CSkinManager
{
	DECLARE_DYNAMIC(CChatDlg)

public:
	CBuddyItem				* m_pBuddyItem;

public:
	CChatDlg(CWnd* pParent = NULL);   // ��׼���캯��
	virtual ~CChatDlg();

protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV ֧��

	virtual void OnCancel();

	DECLARE_MESSAGE_MAP()
};
