//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ generated include file.
// Used by QQ.rc
//
#define IDD_QQ_DIALOG                   102
#define IDR_MAINFRAME                   128
#define IDD_LOGON                       129
#define IDD_DIALOG1                     130
#define IDD_PASSWORD_KEYBOARD           130
#define IDD_DIALOG2                     131
#define IDD_SKIN                        131
#define IDD_DIALOG3                     132
#define IDD_CHAT                        132
#define IDC_ACCOUNT                     1000
#define IDC_EDIT1                       1002
#define IDC_EDIT_WRITE                  1002
#define IDC_EDIT_WRITE2                 1003
#define IDC_EDIT_SEARCH                 1003
#define IDC_EDIT_PASS                   5687
#define IDC_TABCTRL                     5688
#define IDC_MAINMENU                    5689
#define IDC_WNDMIN                      5690
#define IDC_WNDSKIN                     5691
#define IDC_BT_WRITE                    5692
#define IDC_BUDDYLIST                   5693
// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        133
#define _APS_NEXT_COMMAND_VALUE         32771
#define _APS_NEXT_CONTROL_VALUE         1003
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
