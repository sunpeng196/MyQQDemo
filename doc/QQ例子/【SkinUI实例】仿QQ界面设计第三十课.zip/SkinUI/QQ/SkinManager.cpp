// SkinManager.cpp : ʵ���ļ�
//

#include "stdafx.h"
#include "QQ.h"
#include "SkinManager.h"

// CSkinManager �Ի���

IMPLEMENT_DYNAMIC(CSkinManager, CSkinDialog)

CSkinManager::CSkinManager(UINT nIDTemplate,CWnd* pParent /*=NULL*/)
	: CSkinDialog(nIDTemplate, pParent)
{
	m_pImageBack = NULL;
	m_pImageLogo = NULL;
}

CSkinManager::~CSkinManager()
{
	RenderEngine->RemoveImage(m_pImageBack);
	RenderEngine->RemoveImage(m_pImageLogo);
}

void CSkinManager::DoDataExchange(CDataExchange* pDX)
{
	CSkinDialog::DoDataExchange(pDX);
}


BEGIN_MESSAGE_MAP(CSkinManager, CSkinDialog)
	ON_BN_CLICKED(IDC_WNDMIN,OnBnClickWindowMin)
	ON_WM_LBUTTONDOWN()
	ON_WM_DESTROY()
END_MESSAGE_MAP()

void CSkinManager::DrawClientArea( CDC*pDC,int nWidth,int nHeight )
{
	pDC->FillSolidRect(0,0,nWidth,nHeight,RGB(249,245,237));

	if ( m_pImageBack != NULL && !m_pImageBack->IsNull() )
	{
		m_pImageBack->DrawExtrude(pDC,CRect(0,0,nWidth,nHeight),GlobalUnits->m_bLeftDrawExtrude);
	}

	//���Ʊ߿�
	RenderEngine->DrawRoundRect(pDC->GetSafeHdc(),CRect(0,0,nWidth-1,nHeight-1),6,6,1,RGB(92,89,82));

	if ( m_pImageLogo != NULL && !m_pImageLogo->IsNull() )
		m_pImageLogo->DrawImage(pDC,5,5);
}

BOOL CSkinManager::OnInitDialog()
{
	CSkinDialog::OnInitDialog();

	HDC hParentDC = GetBackDC();

	m_pImageBack = RenderEngine->GetImage(GlobalUnits->m_szDefaultSkin);
	m_pImageLogo = RenderEngine->GetImage(TEXT("QQ\\Main_Title.png"));

	GlobalUnits->m_WindowArray.push_back(this);

	CRect rcClient;
	GetClientRect(&rcClient);

	m_btClose.Create(NULL,WS_VISIBLE|WS_CHILD,CRect(rcClient.Width()-41,0,0,0),this,IDCANCEL);
	m_btClose.SetBackImage(TEXT("\\QQ\\Button\\btn_close_normal.png"),TEXT("\\QQ\\Button\\btn_close_highlight.png"),TEXT("\\QQ\\Button\\btn_close_down.png"),TEXT("\\QQ\\Button\\btn_close_normal.png"));
	m_btClose.SetButtonType(en_PushButton);
	m_btClose.SetParentBack(hParentDC);
	m_btClose.SetSize(39,20);

	m_btMin.Create(NULL,WS_VISIBLE|WS_CHILD,CRect(rcClient.Width()-69,0,0,0),this,IDC_WNDMIN);
	m_btMin.SetBackImage(TEXT("\\QQ\\Button\\btn_mini_normal.png"),TEXT("\\QQ\\Button\\btn_mini_highlight.png"),TEXT("\\QQ\\Button\\btn_mini_down.png"),TEXT("\\QQ\\Button\\btn_mini_normal.png"));
	m_btMin.SetButtonType(en_PushButton);
	m_btMin.SetParentBack(hParentDC);
	m_btMin.SetSize(28,20);

	//����Բ��
	CRgn rgn;
	rgn.CreateRoundRectRgn(0,0,rcClient.Width(),rcClient.Height(),4,4);
	SetWindowRgn(rgn,FALSE);

	return TRUE;
}

void CSkinManager::OnBnClickWindowMin()
{
	ShowWindow(SW_MINIMIZE);
}

void CSkinManager::OnLButtonDown( UINT nFlags, CPoint point )
{
	PostMessage(WM_NCLBUTTONDOWN,HTCAPTION,MAKELPARAM(point.x,point.y));

	CSkinDialog::OnLButtonDown(nFlags, point);
}

void CSkinManager::UpdateSkin()
{
	RenderEngine->RemoveImage(m_pImageBack);
	m_pImageBack = RenderEngine->GetImage(GlobalUnits->m_szDefaultSkin);

	for (int i=0;i<GlobalUnits->m_WindowArray.size();i++)
	{
		CSkinManager * pSkinManager = GlobalUnits->m_WindowArray.at(i);

		if (pSkinManager->GetSafeHwnd() == NULL ) continue;
		
		pSkinManager->ModifyStyle(WS_CLIPCHILDREN,0);

		pSkinManager->Invalidate(FALSE);

		pSkinManager->ModifyStyle(0,WS_CLIPCHILDREN);
	}
}

void CSkinManager::OnDestroy()
{
	vector<CSkinManager*>::iterator iter = GlobalUnits->m_WindowArray.begin();

	for(; iter != GlobalUnits->m_WindowArray.end(); iter++ )
	{
		CSkinManager* pSkinManager = (CSkinManager*)*iter;
		if( pSkinManager == (CSkinManager*)this )
		{
			GlobalUnits->m_WindowArray.erase(iter);
			break;
		}
	}

	__super::OnDestroy();
}

// CSkinManager ��Ϣ��������
