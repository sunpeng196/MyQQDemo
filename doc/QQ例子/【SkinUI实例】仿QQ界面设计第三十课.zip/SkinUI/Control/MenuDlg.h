#pragma once

#include "DlgControlItem.h"

// CMenuDlg �Ի���

class CMenuDlg : public CDlgControlItem
{
	DECLARE_DYNAMIC(CMenuDlg)
protected:
	CMenu				m_MenuBar;

public:
	CMenuDlg(CWnd* pParent = NULL);   // ��׼���캯��
	virtual ~CMenuDlg();

protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV ֧��

	DECLARE_MESSAGE_MAP()
public:
	virtual BOOL OnInitDialog();

	//����Ҽ�
	afx_msg void OnRButtonDown(UINT nFlags, CPoint point);
protected:
	virtual BOOL OnCommand(WPARAM wParam, LPARAM lParam);
};
