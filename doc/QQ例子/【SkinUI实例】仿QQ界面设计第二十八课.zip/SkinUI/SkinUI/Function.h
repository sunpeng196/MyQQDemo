#ifndef FUN_HEAD_FILE
#define FUN_HEAD_FILE

#include "SkinUI.h"

SKINUI_CLASS void WINAPI OutputString(LPCTSTR lpStr, ...);


#endif