// QQDlg.h : ͷ�ļ�
//

#pragma once
#include "LogonDlg.h"

// CQQDlg �Ի���
class CQQDlg : public CSkinDialog
{
protected:
	CLogonDlg				m_LogonDlg;

public:
	CQQDlg(CWnd* pParent = NULL);   // ��׼���캯��
	virtual ~CQQDlg();

protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV ֧��
	
	virtual BOOL OnInitDialog();
	
	LRESULT OnLogonMessage(WPARAM wParam,LPARAM lParam);

	DECLARE_MESSAGE_MAP()
};
