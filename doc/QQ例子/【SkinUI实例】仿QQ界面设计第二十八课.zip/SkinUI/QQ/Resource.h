//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ generated include file.
// Used by QQ.rc
//
#define IDD_QQ_DIALOG                   102
#define IDR_MAINFRAME                   128
#define IDD_LOGON                       129
#define IDD_DIALOG1                     130
#define IDD_PASSWORD_KEYBOARD           130
#define IDC_ACCOUNT                     1000
#define IDC_EDIT_PASS                   5687

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        131
#define _APS_NEXT_COMMAND_VALUE         32771
#define _APS_NEXT_CONTROL_VALUE         1002
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
