// QQDlg.cpp : ʵ���ļ�
//

#include "stdafx.h"
#include "QQ.h"
#include "QQDlg.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#endif


// CQQDlg �Ի���




CQQDlg::CQQDlg(CWnd* pParent /*=NULL*/)
	: CSkinDialog(IDD_QQ_DIALOG, pParent)
{
}

CQQDlg::~CQQDlg()
{

}

void CQQDlg::DoDataExchange(CDataExchange* pDX)
{
	CSkinDialog::DoDataExchange(pDX);
}

BEGIN_MESSAGE_MAP(CQQDlg, CSkinDialog)
	ON_MESSAGE(WM_USER_LOGON,OnLogonMessage)
END_MESSAGE_MAP()


// CQQDlg ��Ϣ��������

BOOL CQQDlg::OnInitDialog()
{
	CSkinDialog::OnInitDialog();

	//����������
	WINDOWPLACEMENT   wp;   
	wp.length=sizeof(WINDOWPLACEMENT);   
	wp.flags=WPF_RESTORETOMAXIMIZED;   
	wp.showCmd=SW_HIDE;   
	SetWindowPlacement(&wp);

	//������½����
	m_LogonDlg.Create(IDD_LOGON,this);
	m_LogonDlg.CenterWindow();
	m_LogonDlg.ShowWindow(SW_SHOW);

	return TRUE;
}

LRESULT CQQDlg::OnLogonMessage( WPARAM wParam,LPARAM lParam )
{
	//���ٵ�½
	m_LogonDlg.PostMessage(WM_CLOSE);

	//��ʾ������
	WINDOWPLACEMENT   wp;   
	wp.length=sizeof(WINDOWPLACEMENT);   
	wp.flags=WPF_RESTORETOMAXIMIZED;   
	wp.showCmd=SW_SHOW;   
	SetWindowPlacement(&wp);  

	SetWindowPos(NULL,0,0,281,700,SWP_SHOWWINDOW);
	CenterWindow();  

	return TRUE;
}
