#pragma once


// CListBoxDlg �Ի���
#include "DlgControlItem.h"

class CListBoxDlg : public CDlgControlItem
{
	DECLARE_DYNAMIC(CListBoxDlg)

protected:
	CSkinListBox			m_ListBox;
	CSkinListBox			m_ListBox2;

public:
	CListBoxDlg(CWnd* pParent = NULL);   // ��׼���캯��
	virtual ~CListBoxDlg();

// �Ի�������
	enum { IDD = IDD_LISTBOXDLG };

protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV ֧��

	DECLARE_MESSAGE_MAP()
public:
	afx_msg void OnBnClickedButton1();
	virtual BOOL OnInitDialog();
	afx_msg void OnBnClickedButton14();
	afx_msg void OnBnClickedButton16();
	afx_msg void OnBnClickedButton17();
	afx_msg void OnBnClickedButton15();
	afx_msg void OnBnClickedButton18();
	afx_msg void OnBnClickedButton2();
	afx_msg void OnBnClickedButton3();
	afx_msg void OnBnClickedButton4();
	afx_msg void OnRbnDblclkList1();
	afx_msg void OnRbnDblclkList2();
};
