#pragma once

class CGlobalUnits
{
public:
	TCHAR						m_szDefaultSkin[MAX_PATH];

public:
	CGlobalUnits(void);
	~CGlobalUnits(void);

public:
	static CGlobalUnits*GetInstance();
};

#define GlobalUnits		CGlobalUnits::GetInstance()