#include "StdAfx.h"
#include "GlobalUnits.h"

CGlobalUnits::CGlobalUnits(void)
{
	m_szDefaultSkin[0]=0;
}

CGlobalUnits::~CGlobalUnits(void)
{
}

CGlobalUnits* CGlobalUnits::GetInstance()
{
	static CGlobalUnits _Instance;

	return &_Instance;
}
