function SetCaption(self, text)
    self.Caption:put_text(text)
end

function SetIcon(self, file)
    self.Icon:put_file(file)
end

function SetTitleColor(self, color)
    self.Caption:put_color(color)
    self.Caption:Invalidate()
end

function SetTitleVisible(self, visible)
	self.Icon:put_hidden(not visible)
	self.Caption:put_hidden(not visible)
end